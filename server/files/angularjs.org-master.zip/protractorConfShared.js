exports.config = {
  baseUrl: process.env.ANGULAR_HOME_HOST || 'http://angularjs.org',
  specs: [
    'test/angularjs.org.spec.js',
  ]
};